<?php

namespace App\Livewire;

use Livewire\Component;

class ProfilPimpinan extends Component
{
  public function render()
  {
    return view('livewire.profil-pimpinan');
  }
}
