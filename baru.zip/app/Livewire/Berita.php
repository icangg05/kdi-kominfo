<?php

namespace App\Livewire;

use Livewire\Component;

class Berita extends Component
{
  public function render()
  {
    return view('livewire.berita');
  }
}
