<?php

namespace App\Livewire;

use Livewire\Component;

class Galeri extends Component
{
  public function render()
  {
    return view('livewire.galeri');
  }
}
