<?php

namespace App\Livewire;

use Livewire\Component;

class Tupoksi extends Component
{
  public function render()
  {
    return view('livewire.tupoksi');
  }
}
