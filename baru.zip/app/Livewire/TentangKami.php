<?php

namespace App\Livewire;

use Livewire\Component;

class TentangKami extends Component
{
    public function render()
    {
        return view('livewire.tentang-kami');
    }
}
