<?php

namespace App\Livewire;

use Livewire\Component;

class Dokumen extends Component
{
  public function render()
  {
    return view('livewire.dokumen');
  }
}
